#include "../kernel/types.h"
#include "user.h"

int main(int argc, char *argv[]) {
    ps();
    
    return 0;
}
